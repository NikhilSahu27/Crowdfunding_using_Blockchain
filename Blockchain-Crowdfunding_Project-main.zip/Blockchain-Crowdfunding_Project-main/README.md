# Blockchain-Crowdfunding_Project
It is a simple Crowdfunding project where multiple parties can fund into their selected institute with ethereum currency. The link to the website is https://fundd-me.netlify.app/
